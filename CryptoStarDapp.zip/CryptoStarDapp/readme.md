1) Your ERC-721 Token Name - "Udacity Token"
2) Your ERC-721 Token Symbol - "USD"
3) Version of the Truffle is v5.0.26 
4) Verion of OpenZeppelin-Solidity used  2.3.0